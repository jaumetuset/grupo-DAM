from odoo import models, fields, api


class GrupoA(models.Model):
    _name = 'simarropop.simarropop'  # Asegúrate de que este nombre coincide con el del CSV
    _description = 'Modelo Simarropop'

    name = fields.Char(string="Nombre")

class ResPartner(models.Model):
    _inherit = 'res.partner'

    is_premium = fields.Boolean(string="Premium", default=False)

    @api.model
    def create(self, vals):
        # Crear el registro del partner
        partner = super(ResPartner, self).create(vals)

        # Lógica para crear la factura de 10 euros
        invoice = self._create_invoice(partner)

        # Generar la URL para descargar el PDF
        if invoice:
            pdf_url = f"/report/pdf/account.report_invoice/{invoice.id}"
            partner.message_post(body=f"Descarga tu factura: <a href='{pdf_url}' target='_blank'>Factura PDF</a>")

        return partner

    def _create_invoice(self, partner):
        """Crea una factura de 10 euros para el nuevo partner y la marca como pagada."""
        company = self.env.company

        # Crear la factura
        invoice = self.env['account.move'].create({
            'partner_id': partner.id,
            'move_type': 'out_invoice',  # Factura de cliente
            'invoice_date': fields.Date.today(),
            'company_id': company.id,
            'currency_id': company.currency_id.id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Suscripción Premium',
                'quantity': 1,
                'price_unit': 10.0,
                'tax_ids': [],
            })]
        })

        # Confirmar la factura (pasa de borrador a abierta)
        invoice.action_post()

        # Registrar el pago
        payment = self.env['account.payment.register'].with_context(
            active_ids=invoice.ids, active_model='account.move'
        ).create({
            'amount': invoice.amount_total,
            'payment_date': fields.Date.today(),
            'payment_method_line_id': self.env.ref('account.account_payment_method_manual_in').id,
            'journal_id': self.env['account.journal'].search([('type', '=', 'bank')], limit=1).id,
        })
        payment.action_create_payments()

        return invoice