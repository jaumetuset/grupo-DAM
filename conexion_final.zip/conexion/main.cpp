#include <QApplication>
#include "ventprinrest.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QVector<Usuario*> usuarios;
    VentPrinREST *ventanaPrincipal = new VentPrinREST(usuarios);
    ventanaPrincipal->show();
    return app.exec();
}

