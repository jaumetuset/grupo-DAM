#ifndef FORMADD_H
#define FORMADD_H

#include "ui_formAdd.h"

#include <QDialog>

namespace Ui {
    class FormAdd;
}

class FormAdd : public QDialog
{
    Q_OBJECT

public:

    Ui::Dialog *ui;

    FormAdd(QWidget *parent = 0);
    QString nombre();
    QString email();
    QString password();
    bool admin();
    QString poblacion();
    QString tipoUsuario(bool isAdmin);  


signals:
    void formAccepted();

public slots:
    void slotBtnSave();
    void sloBtnCancel();
    void slotAdminUser();

};

#endif // FORMADD_H

