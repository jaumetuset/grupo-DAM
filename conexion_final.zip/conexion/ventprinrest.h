#ifndef VENTPRINTREST_H
#define VENTPRINTREST_H

#include <QMainWindow>
#include <QPaintEvent>
#include <QPushButton> 
#include <QDialog> 
#include <QAction> 
#include "ui_ventprinrest.h"
#include "conexion.h"
#include "usuario.h"
#include "formedit.h"
#include <QTableWidget> 
#include <QAbstractTableModel>

class Conexion;
class ModeloTabla;

class VentPrinREST : public QMainWindow , public Ui::VentPrinREST{
Q_OBJECT

public: 

 	VentPrinREST(QVector<Usuario*> usuarios, QWidget* parent = 0);
	ModeloTabla * modelo;
 	Conexion *con;
	Conexion *conOdoo;
        FormEdit *formEdit;

		

public slots:  
	void slotActualizarTabla();
	void slotBtnAdd();
	void slotBtnEdit();
	void slotBtnDelete();
	
	void slotUsuarioRecibidoParaEdicion(int id, const QString &name, const QString &email, const QString &password, bool admin, const QString &poblacion);

       	
signals: 

	void actualizarTabla();

};

class ModeloTabla : public QAbstractTableModel {
Q_OBJECT

public : 
	
	QVector<QVector<QString>> losUsuarios;

	ModeloTabla(const QVector<QVector<QString>>& usuarios, QObject *parent = 0);
	int columnCount(const QModelIndex &parent = QModelIndex()) const;
	int rowCount(const QModelIndex &parent = QModelIndex()) const;
	QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
	Qt::ItemFlags flags(const QModelIndex &index) const;
	
	bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole);

	QVariant headerData (int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const;
	
	void actualizarUsuarios(const QVector<QVector<QString>> &nuevosUsuarios);

	
public slots : 

	//void slotTemporizador();
	
};

#endif 

