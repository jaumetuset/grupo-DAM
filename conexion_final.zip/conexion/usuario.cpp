#include "usuario.h"

#include <math.h>
#include <stdlib.h>
#include <QDebug>

Usuario::Usuario() : Usuario(0,0,0,0,0,0){ }

Usuario::Usuario(int id, QString name, QString password, QString email, bool admin, QString poblacion) : id(id),name(name), password(password), email(email), admin(admin) , poblacion(poblacion){

}

