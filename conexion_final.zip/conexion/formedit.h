#ifndef FORMEDIT_H
#define FORMEDIT_H

#include "usuario.h"
#include "ui_formEdit.h"
#include <QNetworkAccessManager>
#include <QNetworkReply>

class FormEdit : public QDialog
{
    Q_OBJECT

public:

    Ui::formEdit *ui;
    Usuario* usuario;  

    int idUsuario;

    FormEdit(QWidget *parent = nullptr, Usuario* usuario = nullptr);
    FormEdit(QWidget *parent, int idUsuario);
    
    QString nombre();
    QString email();
    QString password();
    bool admin();
    QString poblacion();

    void loadUsuarioFromAPI(int id);
    void handleLoadUserResponse();

    int getIdUsuario() const; 
    
    void setUsuario(int id, const QString &name, const QString &email, const QString &password, bool admin, const QString &poblacion);
    
    void setIdUsuario(int id);
        
    Usuario* getUsuario();
    
    void handleNetworkReply();
    
private:
    QNetworkAccessManager *manager; 

public slots:
    void slotBtnSave();
    void sloBtnCancel();
};

#endif // FORMEDIT_H

