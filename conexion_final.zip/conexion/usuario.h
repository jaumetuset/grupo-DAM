#ifndef USUARIO_H
#define USUARIO_H

#include <QString>
#include <QPainter>

class Usuario {

public :

	int id;
	QString name;
	QString password;
	QString email;
	bool admin;
	QString poblacion;
	
	Usuario(int id, QString name, QString password, QString email, bool admin, QString poblacion);
	Usuario();
	

	int getId() const { return id;}
	void setId(const int id_user){ id = id_user;}

	QString getName() const { return name; } 
	void setName(const QString &name_user) { name = name_user;}
	
	QString getPassword() const { return password ; }
	void setPassword(const QString &password_user) { password = password_user;}
	
	QString getEmail() const { return email;}
	void setEmail(const QString &email_user) { email = email_user;} 
	
	bool getAdmin() const { return admin;}
	void setAdmin(const bool &admin_user) { admin = admin_user; }

	QString getPoblacion() const { return poblacion;}
	void setPoblacion(const QString &poblacion_user) { poblacion = poblacion_user;} 
	
		
};


#endif






