#include "formadd.h"
#include "ui_formAdd.h"

FormAdd::FormAdd(QWidget *parent) : QDialog(parent), ui(new Ui::Dialog)
{
    ui->setupUi(this);
    connect(ui->btnSave, SIGNAL(clicked()), this, SLOT(slotBtnSave()));
    connect(ui->btnCancel, SIGNAL(clicked()), this, SLOT(sloBtnCancel()));
    
   connect(ui->checkBoxAdmin, SIGNAL(toggled(bool)), this, SLOT(slotAdminUser()));
   connect(ui->checkBoxCliente, SIGNAL(toggled(bool)), this, SLOT(slotAdminUser()));

}

QString FormAdd::nombre() {
    return ui->lineEdit_name->text();
}

QString FormAdd::email() {
    return ui->lineEdit_email->text();
}

QString FormAdd::password() {
    return ui->lineEdit_password->text();
}

bool FormAdd::admin() {
    return ui->checkBoxAdmin->isChecked();
}

QString FormAdd::poblacion() {
    return ui->lineEdit_poblacion->text();
}

void FormAdd::slotBtnSave() {
    accept(); 
}

void FormAdd::sloBtnCancel() {
    reject();  
}

void FormAdd::slotAdminUser()
{
    if (ui->checkBoxCliente->isChecked()) {
        ui->checkBoxAdmin->setChecked(false);  
        ui->label_admin->setText("Cliente");
    } 
    else if (ui->checkBoxAdmin->isChecked()) {
        ui->checkBoxCliente->setChecked(false);  
        ui->label_admin->setText("Admin");
    } 
    else {
        ui->label_admin->clear();  
    }
}


QString FormAdd::tipoUsuario(bool isAdmin) {
    return isAdmin ? "Admin" : "Cliente";
}

