#include "conexion.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDebug>
#include <QTimer>
#include <QModelIndex>


Conexion::Conexion(VentPrinREST *ventana, QObject *parent) : QObject(parent), ventanaPrincipal(ventana) {
    manager = new QNetworkAccessManager(this);


    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(slotRespuestaFinalizada(QNetworkReply*)));
    
}

void Conexion::fetchUsers() {
    QUrl url("http://api.grupoa.com:8080/MyApp/usuarios");  
    QNetworkRequest request(url);
    manager->get(request);  
}

void Conexion::addUsuario(const QVector<QString> &nuevoUsuario) {
    usuarios.append(nuevoUsuario);  
    emit usuariosActualizados();   
}

void Conexion::actualizarBBDD(const QVector<QString> &nuevoUsuario) {
    QJsonObject json;
    json["name"] = nuevoUsuario[1];  
    json["email"] = nuevoUsuario[2]; 
    json["password"] = nuevoUsuario[3];
    json["admin"] = (nuevoUsuario[4] == "Sí") ? true : false;
    json["poblacion"] = nuevoUsuario[5];

    QJsonDocument doc(json);
    QByteArray data = doc.toJson();  
    
    QUrl url("http://api.grupoa.com:8080/MyApp/usuarios");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");      

    QNetworkReply *reply = manager->post(request, data);
    connect(reply, SIGNAL(finished()), this, SLOT(slotUsuarioAgregado()));

}

void Conexion::slotUsuarioAgregado() {
    QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
    if (reply) {
        if (reply->error() == QNetworkReply::NoError) {
            qDebug() << "Usuario agregado correctamente.";
            emit usuarioAgregado();  
            emit usuariosActualizados();
        } else {
            qDebug() << "Error al agregar usuario:" << reply->errorString();
        }
        reply->deleteLater();
    }
    
    
}

//respuesta para listar usuarios que guarda la informacion de cada usuario en una lista y la respuesta de un solo usuario al extraer los datos del usuario y se envian para editarlo
void Conexion::slotRespuestaFinalizada(QNetworkReply *reply) {
	
    if (reply->error() != QNetworkReply::NoError) {
        qDebug() << "Error en la solicitud:" << reply->errorString();
        reply->deleteLater();
        return;
    }

    QByteArray responseData = reply->readAll();
    datosLeidos = responseData;
    
    QJsonDocument jsonResponse = QJsonDocument::fromJson(responseData);
	qDebug() << " Slot respuesta finalizada conexion :: " <<  QString(responseData);
    if (jsonResponse.isArray()) {  
        QJsonArray usersArray = jsonResponse.array();
        usuarios.clear();  

        for (const QJsonValue &value : usersArray) {
            if (!value.isObject()) continue;
            QJsonObject user = value.toObject();

            QVector<QString> usuario;
            usuario.append(QString::number(user.value("id").toInt()));
            usuario.append(user.value("name").toString());
            usuario.append(user.value("email").toString()); 
            usuario.append(user.value("password").toString());
            usuario.append(user.value("admin").toBool() ? "Admin" : "Cliente");
            usuario.append(user.value("poblacion").toString());

            usuarios.append(usuario);
        }
        
        emit usuariosActualizados();
    } 
    else if (jsonResponse.isObject()) {  
        QJsonObject userObject = jsonResponse.object();
        int id = userObject.value("id").toInt();
        QString name = userObject.value("name").toString();
        QString email = userObject.value("email").toString();
        QString password = userObject.value("password").toString();
        bool admin = userObject.value("admin").toBool();
        QString poblacion = userObject.value("poblacion").toString();

        emit usuarioRecibidoParaEdicion(id, name, email, password, admin, poblacion);
    }
    else {
        qDebug() << "La respuesta no es un formato JSON válido.";
    }

    reply->deleteLater();
}

//eliminarUsuario(int id): Esta función realiza una solicitud DELETE para eliminar un usuario específico mediante su ID. 
//Después de realizar la solicitud, se conecta a slotUsuarioEliminado.
void Conexion::eliminarUsuario(int id) {
    QUrl url(QString("http://api.grupoa.com:8080/MyApp/usuarios/%1").arg(id));
    QNetworkRequest request(url);
    
    QNetworkReply *reply = manager->deleteResource(request);
    connect(reply, &QNetworkReply::finished, this, &Conexion::slotUsuarioEliminado);
}

//slotUsuarioEliminado(): Maneja la respuesta de la eliminación del usuario. Si la solicitud se completa correctamente, 
//emite una señal (usuariosActualizados) para actualizar la lista de usuarios. En caso de error, se muestra un mensaje de error en el qDebug.
void Conexion::slotUsuarioEliminado() {
    QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
    if (reply) {
        if (reply->error() == QNetworkReply::NoError) {
            qDebug() << "Usuario eliminado correctamente.";
            emit usuariosActualizados();  
        } else {
            qDebug() << "Error al eliminar usuario:" << reply->errorString();
        }
        reply->deleteLater();
    } 
}

void Conexion::editarUsuario(int id) {
    QUrl url(QString("http://api.grupoa.com:8080/MyApp/usuarios/%1").arg(id));
    QNetworkRequest request(url);
    QNetworkReply *reply = manager->get(request);  
    
    connect(reply, SIGNAL(finished()), this, SLOT(procesarRespuestaEdicion()));

}


//maneja la respuesta de una solicitud de red y la procesa para extraer los datos 
//
void Conexion::procesarRespuestaEdicion() {
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (reply->error() != QNetworkReply::NoError) {
        qDebug() << "Error en la solicitud:" << reply->errorString();
        reply->deleteLater();
        return;
    }

   // QByteArray respuesta = reply->readAll();
   QByteArray respuesta = datosLeidos;

    if (respuesta.isEmpty()) {
        qDebug() << "La respuesta de la API está vacía.";
        reply->deleteLater();
        return;
    }

    QJsonDocument jsonDoc = QJsonDocument::fromJson(respuesta);
    qDebug() << "Respuesta de la API (formato JSON): " << jsonDoc.toJson();

    if (jsonDoc.isObject()) { 
        QJsonObject jsonObj = jsonDoc.object();
        int id = jsonObj["id"].toInt();
        QString nombre = jsonObj["nombre"].toString();
        QString email = jsonObj["email"].toString();
        QString password = jsonObj["password"].toString();
        bool admin = jsonObj["admin"].toBool();
        QString poblacion = jsonObj["poblacion"].toString();

        emit usuarioRecibidoParaEdicion(id, nombre, email, password, admin, poblacion);
    } else {
        qDebug() << "La respuesta no es un objeto JSON válido.";
    }

    //libera recursos de la memoria
    reply->deleteLater();
}

//obtener datos de usuario
void Conexion::obtenerDatosUsuario(int idUsuario) {

	QString stringURL("http://api.grupoa.com:8080/MyApp/usuarios/");
	stringURL = stringURL + QString::number(idUsuario);
	
	qDebug() << "conexion.cpp::obtenerDatosUsuario url:" << stringURL ;
    QUrl url(stringURL);
    QNetworkRequest request(url);

    QNetworkReply* reply = manager->get(request);
    
    connect(reply, SIGNAL(finished()), this, SLOT(procesarRespuesta()));

}

void Conexion::procesarRespuesta() {
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender()); 
    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();
        
        response = datosLeidos;
        
        QJsonDocument doc = QJsonDocument::fromJson(response);
        QJsonObject json = doc.object();
                
        int id = json["id"].toInt();
        QString name = json["name"].toString();
        QString email = json["email"].toString();
        QString password = json["password"].toString();
        bool admin = json["admin"].toBool();
        QString poblacion = json["poblacion"].toString();

	//qdebug del id 
	qDebug() << " El id conexion es : " << id;

        emit usuarioRecibidoParaEdicion(id, name, email, password, admin, poblacion); 
        
    } else {
        qDebug() << "conexion.cpp procesarRespuesta Error al obtener los datos del usuario: " << reply->errorString();
    }
    reply->deleteLater();  
}

void Conexion::guardarUsuarioEditado(int id, const QString &nombre, const QString &email, const QString &password, bool admin, const QString &poblacion) {
    QUrl url(QString("http://api.grupoa.com:8080/MyApp/usuarios/%1").arg(id));  
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject jsonObj;
    jsonObj["nombre"] = nombre;
    jsonObj["email"] = email;
    jsonObj["password"] = password;
    jsonObj["admin"] = admin;
    jsonObj["poblacion"] = poblacion;

    QJsonDocument jsonDoc(jsonObj);
    QByteArray data = jsonDoc.toJson();

    manager->put(request, data);
}


void Conexion::slotUsuarioEdit() {
    QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
    if (reply) {
        if (reply->error() == QNetworkReply::NoError) {
            qDebug() << "Usuario editado correctamente.";
            emit usuariosActualizados();  
        } else {
            qDebug() << "Editar usuario:" << reply->errorString();
        }
        reply->deleteLater();
    } 
}

void Conexion::guardarCambios(Usuario* usuario) {
    QUrl url(QString("http://api.grupoa.com:8080/MyApp/usuarios/%1").arg(usuario->getId()));
    QNetworkRequest request(url);
    
    QJsonObject json;
    json["name"] = usuario->getName();
    json["email"] = usuario->getEmail();
    json["password"] = usuario->getPassword();
    json["admin"] = usuario->getAdmin();
    json["poblacion"] = usuario->getPoblacion();

    QJsonDocument doc(json);
    QByteArray data = doc.toJson();

    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    
    QNetworkReply *reply = manager->put(request, data);

}



