#include "formedit.h"
#include "ui_formEdit.h"
#include <QJsonObject>
#include <QJsonDocument>
#include <QNetworkRequest>
#include <QNetworkAccessManager>
#include <QUrl>
#include <QMessageBox>


FormEdit::FormEdit(QWidget *parent, Usuario* usuario) 
    : QDialog(parent), manager(new QNetworkAccessManager(this)), ui(new Ui::formEdit), usuario(usuario)
{

    ui->setupUi(this);
    
    qDebug() << "FormEdit creado con usuario:" << (usuario ? usuario->getName() : "nullptr");

    ui->lineEdit_name_edit->setEnabled(true);
    ui->lineEdit_email_edit->setEnabled(true);
    ui->lineEdit_password_edit->setEnabled(true);
    ui->checkBoxAdmin_edit->setEnabled(true);
    ui->checkBoxCliente_edit->setEnabled(true);
    ui->lineEdit_poblacion_edit->setEnabled(true);

    if (usuario) {
        qDebug() << "FormEdit creado con usuario:" << usuario->getName();
        setUsuario(usuario->getId(), usuario->getName(), usuario->getEmail(), usuario->getPassword(), usuario->getAdmin(), usuario->getPoblacion());
    } else {
        qDebug() << "FormEdit creado con usuario: nullptr";
    }

    connect(ui->btnSave, SIGNAL(clicked()), this, SLOT(slotBtnSave()));
    connect(ui->btnCancel, SIGNAL(clicked()), this, SLOT(sloBtnCancel()));
}


FormEdit::FormEdit(QWidget *parent, int idUsuario)
    : QDialog(parent), manager(new QNetworkAccessManager(this)), ui(new Ui::formEdit), idUsuario(idUsuario), usuario(nullptr)
{
    qDebug() << "ID de usuario recibido en el constructor:" << idUsuario;
	
	usuario = NULL;
 
    if (idUsuario <= 0) {
        qDebug() << "Error: El ID de usuario no es válido en el constructor.";
        QMessageBox::warning(this, "Error", "El ID proporcionado no es válido.");
        return;  
    }

    ui->setupUi(this);
    loadUsuarioFromAPI(idUsuario);
    
    connect(ui->btnSave, SIGNAL(clicked()), this, SLOT(slotBtnSave()));
    connect(ui->btnCancel, SIGNAL(clicked()), this, SLOT(sloBtnCancel()));
}


void FormEdit::loadUsuarioFromAPI(int id) {
    qDebug() << "Cargando usuario con ID:" << id;
    
    if (id <= 0) {
        qDebug() << "Error: ID no válido.";
        QMessageBox::warning(this, "Error", "El ID proporcionado no es válido.");
        return;
    }

    QUrl url("http://api.grupoa.com:8080/MyApp/usuarios/" + QString::number(id));
    QNetworkRequest request(url);
    QNetworkReply* reply = manager->get(request);

   connect(reply, &QNetworkReply::finished, this, &FormEdit::handleLoadUserResponse);


}


//maneja la respuesta de la solicitud API cargar datos en la ui
void FormEdit::handleLoadUserResponse() {
    QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray responseData = reply->readAll();
        
        qDebug() << "Respuesta cruda de la API:" << responseData;

        if (responseData.trimmed() == "null") {
            qDebug() << "Error: La respuesta de la API es null.";
            QMessageBox::warning(this, "Error", "No se encontró el usuario con el ID especificado.");
            return;
        }

        QJsonDocument doc = QJsonDocument::fromJson(responseData);
        
        if (doc.isNull()) {
            qDebug() << "Error: El JSON recibido no es válido.";
        } else {
            QJsonObject json = doc.object();
            qDebug() << "Datos recibidos de la API:" << json;

            if (json.isEmpty()) {
                qDebug() << "Error: El objeto JSON está vacío.";
            } else {
                if (usuario==NULL) {
                    usuario = new Usuario(json["id"].toInt(),
                                          json["name"].toString(),
                                          json["email"].toString(),
                                          json["password"].toString(),
                                          json["admin"].toBool(),
                                          json["poblacion"].toString());
                } else {
                    usuario->setName(json["name"].toString());
                    usuario->setEmail(json["email"].toString());
                    usuario->setPassword(json["password"].toString());
                    usuario->setAdmin(json["admin"].toBool());
                    usuario->setPoblacion(json["poblacion"].toString());
                }


                setUsuario(usuario->getId(), usuario->getName(), usuario->getEmail(), usuario->getPassword(), usuario->getAdmin(), usuario->getPoblacion());
            }
        }
    } else {
        qDebug() << "Error al cargar los datos: " << reply->errorString();
        QMessageBox::warning(this, "Error", "No se pudo cargar los datos del usuario.");
    }

    reply->deleteLater();
}



void FormEdit::setIdUsuario(int id) {
    idUsuario = id;
}

int FormEdit::getIdUsuario() const {
    return idUsuario;
}

QString FormEdit::nombre() {
    return ui->lineEdit_name_edit->text();
}

QString FormEdit::email() {
    return ui->lineEdit_email_edit->text();
}

QString FormEdit::password() {
    return ui->lineEdit_password_edit->text();
}

bool FormEdit::admin() {
    return ui->checkBoxAdmin_edit->isChecked();
}

QString FormEdit::poblacion() {
    return ui->lineEdit_poblacion_edit->text();
}



void FormEdit::setUsuario(int id, const QString &name, const QString &email, const QString &password, bool admin, const QString &poblacion) {
    idUsuario = id;
    ui->lineEdit_name_edit->setText(name);
    ui->lineEdit_email_edit->setText(email);
    ui->lineEdit_password_edit->setText(password);
    ui->checkBoxAdmin_edit->setChecked(admin);
    ui->lineEdit_poblacion_edit->setText(poblacion);
}


void FormEdit::slotBtnSave() {
    QString nuevoNombre = nombre();
    QString nuevoEmail = email();
    QString nuevaPassword = password();
    bool nuevoAdmin = admin();
    QString nuevaPoblacion = poblacion();

    // Validar si los campos no están vacíos
    if (nuevoNombre.isEmpty() || nuevoEmail.isEmpty() || nuevaPassword.isEmpty() || nuevaPoblacion.isEmpty()) {
        QMessageBox::warning(this, "Campos vacíos", "Todos los campos son obligatorios.");
        return;
    }

    // Actualizar el objeto usuario localmente
    if (usuario) {
        usuario->setName(nuevoNombre);
        usuario->setEmail(nuevoEmail);
        usuario->setPassword(nuevaPassword);
        usuario->setAdmin(nuevoAdmin);
        usuario->setPoblacion(nuevaPoblacion);

        // Mostrar en el QDebug los datos modificados
        qDebug() << "Usuario actualizado: "
                 << "Nombre:" << usuario->getName()
                 << "Email:" << usuario->getEmail()
                 << "Admin:" << usuario->getAdmin()
                 << "Población:" << usuario->getPoblacion();

        // También puedes actualizar la interfaz si es necesario
        setUsuario(usuario->getId(), usuario->getName(), usuario->getEmail(), usuario->getPassword(), usuario->getAdmin(), usuario->getPoblacion());

        // Mostrar mensaje de éxito
        QMessageBox::information(this, "Éxito", "Los cambios se han guardado localmente.");

        // Mostrar los datos del usuario modificados en QDebug
        qDebug() << "Datos del usuario guardados localmente:"
                 << "Nombre:" << usuario->getName()
                 << "Email:" << usuario->getEmail()
                 << "Admin:" << usuario->getAdmin()
                 << "Población:" << usuario->getPoblacion();
    } else {
        QMessageBox::warning(this, "Error", "No se ha cargado el usuario correctamente.");
    }
}


/* PETICION DE GUARDAR Y SUBIR A LA API -> NO FUNCIONA FALTA IMPLEMENTAR METODO EN SPRING BOOT 
void FormEdit::slotBtnSave() {

    qDebug()<< "formedit.cpp slotBtnSave Iniciamos el guardado";
    
    if (!usuario) {
        QMessageBox::warning(this, "Error", "No se ha cargado el usuario correctamente.");
        return;
    }

    QString nuevoNombre = nombre();
    QString nuevoEmail = email();
    QString nuevaPassword = password();
    bool nuevoAdmin = admin();
    QString nuevaPoblacion = poblacion();

    if (nuevoNombre.isEmpty() || nuevoEmail.isEmpty() || nuevaPassword.isEmpty() || nuevaPoblacion.isEmpty()) {
        QMessageBox::warning(this, "Campos vacíos", "Todos los campos son obligatorios.");
        return;
    }


    usuario->setName(nuevoNombre);
    usuario->setEmail(nuevoEmail);
    usuario->setPassword(nuevaPassword);
    usuario->setAdmin(nuevoAdmin);
    usuario->setPoblacion(nuevaPoblacion);


    QJsonObject json;
    json["id"] = usuario->getId();
    json["name"] = usuario->getName();
    json["email"] = usuario->getEmail();
    json["password"] = usuario->getPassword();
    json["poblacion"] = usuario->getPoblacion();
    json["admin"] = usuario->getAdmin();

 
    QUrl url("http://api.grupoa.com:8080/MyApp/usuarios/" + QString::number(usuario->getId()));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Accept", "application/json");

    
    QByteArray data = QJsonDocument(json).toJson();
    QNetworkReply* reply = manager->pust(request, data);

    connect(reply, &QNetworkReply::finished, this, [=]() {
        if (reply->error() == QNetworkReply::NoError) {
            qDebug() << "Usuario actualizado correctamente.";
            accept();
        } else {
            qDebug() << "Error al actualizar los datos: " << reply->errorString();
            QMessageBox::warning(this, "Error", "No se pudo actualizar los datos.");
        }
        reply->deleteLater();
    });
    
        connect(reply, &QNetworkReply::finished, this, &FormEdit::handleNetworkReply);

}
*/

void FormEdit::handleNetworkReply() {
    QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    QByteArray responseData = reply->readAll();
    qDebug() << "Respuesta del servidor:" << responseData;

    if (reply->error() == QNetworkReply::NoError) {
        qDebug() << " Datos actualizados con éxito.";
        accept();  
    } else {
        qDebug() << " Error al actualizar los datos: " << reply->error() << reply->errorString();
        QMessageBox::warning(this, "Error", "No se pudo actualizar los datos.");
    }

    reply->deleteLater();
}


void FormEdit::sloBtnCancel() {

	reject();

}

