#ifndef CONEXION_H
#define CONEXION_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include "ventprinrest.h"
#include "usuario.h"


class VentPrinREST;

class Conexion : public QObject {
    Q_OBJECT

public:

    VentPrinREST *ventanaPrincipal;
    QNetworkAccessManager *manager;
    QVector<QVector<QString>> usuarios; 
    QByteArray datosLeidos;

    Conexion(VentPrinREST *ventana, QObject *parent = 0);
    
    void fetchUsers();  
    void addUsuario(const QVector<QString> &nuevoUsuario);
    void actualizarBBDD(const QVector<QString> &nuevoUsuario);
    void eliminarUsuario(int id);
    void editarUsuario(int id);
    void procesarRespuestaEdicion();
    void obtenerDatosUsuario(int idUsuario);
    void guardarCambios(Usuario*);
    void guardarUsuarioEditado(int id, const QString &nombre, const QString &email, const QString &password, bool admin, const QString &poblacion);


   
    
public slots:
    void slotRespuestaFinalizada(QNetworkReply *reply);
    void slotUsuarioAgregado();
    void slotUsuarioEliminado();
    void slotUsuarioEdit();
    void procesarRespuesta();

        
signals:
    void usuarioAgregado();
    void usuariosActualizados();
    void actualizaPeriodicamente();
    void usuarioRecibidoParaEdicion(int id, const QString &name, const QString &email, const QString &password, bool admin, const QString &poblacion);



};


#endif // CONEXION_H
