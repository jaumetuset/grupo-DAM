#include "ventprinrest.h"

#include <QPainter>
#include <QTimer>
#include <QDebug>
#include <QMdiSubWindow>
#include "ui_ventprinrest.h" 
#include "formadd.h"
#include "usuario.h"
#include <QInputDialog> 

VentPrinREST::VentPrinREST(QVector<Usuario*>usuarios , QWidget *parent) : QMainWindow(parent) {
    setupUi(this);

    resize(800, 600);

    con = new Conexion(this);
    
    connect(con, SIGNAL(usuarioRecibidoParaEdicion(int, QString, QString, QString, bool, QString)), 
        this, SLOT(slotUsuarioRecibidoParaEdicion(int, QString, QString, QString, bool, QString)));


    
    connect(con, SIGNAL(usuariosActualizados()), this, SLOT(slotActualizarTabla()));
    con->fetchUsers(); 

    modelo = new ModeloTabla(con->usuarios, this);
    vista->setModel(modelo);
    
    connect(btnAdd, SIGNAL(clicked()), this, SLOT(slotBtnAdd()));
    connect(btnEdit, SIGNAL(clicked()), this, SLOT(slotBtnEdit()));
    connect(btnDelete, SIGNAL(clicked()), this, SLOT(slotBtnDelete()));
    
      
}

void VentPrinREST:: slotBtnAdd() {

   FormAdd ventana(this);
     if (ventana.exec() == QDialog::Accepted) {
        QString nombre = ventana.nombre();
        QString email = ventana.email();
        QString password = ventana.password();
        bool admin = ventana.admin();
        QString poblacion = ventana.poblacion();
     
     QVector<QString> nuevoUsuario;
        nuevoUsuario.append("");  
        nuevoUsuario.append(nombre);
        nuevoUsuario.append(email);
        nuevoUsuario.append(password);
        nuevoUsuario.append(admin ? "Admin" : "Cliente");
        nuevoUsuario.append(poblacion);

     qDebug() << "Añadido nuevo usuario: " << nombre << email << password << admin << poblacion ;

        con->actualizarBBDD(nuevoUsuario);
    }   
    


}

void VentPrinREST::slotBtnEdit() {
    bool ok;
    int idUsuario = QInputDialog::getInt(this, tr("Editar usuario"), tr("Introduce el ID del usuario a editar:"), 0, 0, 10000, 1, &ok);

    if (ok) {
        qDebug() << "Usuario a editar con ID: " << idUsuario;

        con->obtenerDatosUsuario(idUsuario);
    }
}

void VentPrinREST::slotBtnDelete() {

    bool ok;

    int idUsuario = QInputDialog::getInt(this, tr("Eliminar usuario"),                 tr("Introduce el ID del usuario a eliminar:"), 0, 0, 10000, 1, &ok);
    
    if (ok) {
        qDebug() << "Usuario eliminado: " << idUsuario;
        con->eliminarUsuario(idUsuario);
        
    }
	
     
}

void VentPrinREST::slotActualizarTabla() {
     modelo->actualizarUsuarios(con->usuarios);
}



//recibir los datos de un usuario editar ventana FormEdit
void VentPrinREST::slotUsuarioRecibidoParaEdicion(int id, const QString &name, const QString &email, const QString &password, bool admin, const QString &poblacion) {
    qDebug() << " ventprinrest Recibido para editar: " << id << name << email << password << admin << poblacion;

    FormEdit *ventana = new FormEdit(this, id);
    
    ventana->ui->lineEdit_name_edit->setEnabled(true);
    ventana->ui->lineEdit_email_edit->setEnabled(true);
    ventana->ui->lineEdit_password_edit->setEnabled(true);
    ventana->ui->checkBoxAdmin_edit->setEnabled(true);
    ventana->ui->checkBoxCliente_edit->setEnabled(true);
    ventana->ui->lineEdit_poblacion_edit->setEnabled(true);
  
    ventana->ui->lineEdit_name_edit->setText(name);
    ventana->ui->lineEdit_email_edit->setText(email);
    ventana->ui->lineEdit_password_edit->setText(password);
    ventana->ui->lineEdit_poblacion_edit->setText(poblacion);
    ventana->ui->checkBoxAdmin_edit->setChecked(admin);
    ventana->ui->checkBoxCliente_edit->setChecked(!admin);

    ventana->setIdUsuario(id);

    ventana->setAttribute(Qt::WA_DeleteOnClose);
    ventana->show();
}


//TABLA 
ModeloTabla::ModeloTabla(const QVector<QVector<QString>>& usuariosPasados, QObject *parent) 
    : QAbstractTableModel(parent), losUsuarios(usuariosPasados) {}

int ModeloTabla::columnCount(const QModelIndex &parent) const {
    return 6;  
}

int ModeloTabla::rowCount(const QModelIndex &parent) const {
    return losUsuarios.size();
}

bool ModeloTabla::setData(const QModelIndex &index, const QVariant &value, int role) {
    if (!index.isValid() || role != Qt::EditRole)
        return false;

    losUsuarios[index.row()][index.column()] = value.toString();
    emit dataChanged(index, index); 
    return true;
}

Qt::ItemFlags ModeloTabla::flags(const QModelIndex &index) const {
    if (!index.isValid())
        return Qt::NoItemFlags;

    return Qt::ItemIsSelectable | Qt::ItemIsEnabled | Qt::ItemIsEditable; 
}


QVariant ModeloTabla::data(const QModelIndex &index, int role) const {
    if (!index.isValid() || role != Qt::DisplayRole)
        return QVariant();

 	 QString valor = losUsuarios[index.row()][index.column()];

    if (index.column() == 4) {  
        return valor == "Admin" ? "Admin" : "Cliente";
    }

    return valor;
}

QVariant ModeloTabla::headerData(int section, Qt::Orientation orientation, int role) const {
    if (role != Qt::DisplayRole)
        return QVariant();

    QStringList headers = {"ID", "Nombre", "Email", "Contraseña", "Admin  | Cliente", "Población" };
    return (orientation == Qt::Horizontal) ? headers[section] : QVariant();
}

void ModeloTabla::actualizarUsuarios(const QVector<QVector<QString>> &nuevosUsuarios) {
    beginResetModel();
    losUsuarios = nuevosUsuarios;
    endResetModel();
}


